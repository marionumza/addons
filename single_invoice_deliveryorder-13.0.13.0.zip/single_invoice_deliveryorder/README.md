Odoo 13.0 Community

Installation 
============
* Install the Application => Apps -> Single Invoice For Multiple Delivery Order (Technical Name: single_invoice_deliveryorder)


Create Single Invoice of Multiple delivery
==================================
* Select the delivery orders you want to create single invoice for.
* Select orders which are having same contacts name.


Steps
=====
* Go to Stock after installing the module and select the orders that you want to create single invoice for
  multiple delivery and click on action and click on create single invoice.