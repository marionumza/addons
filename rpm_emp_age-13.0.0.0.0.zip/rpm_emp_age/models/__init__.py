# -*- coding: utf-8 -*-

from . import hr_employee

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
