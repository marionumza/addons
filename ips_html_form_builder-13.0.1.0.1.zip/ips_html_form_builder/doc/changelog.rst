v1.0.1
======
* Fix permission issues with submit actions

v1.0.0
======
* Ported to version 13