Odoo ERP System :- Odoo 13 Version

Installation 
============
* Install the Application => Apps -> Track Deleted Records (Technical Name: deleted_records_info)

Package
============
* sudo pip3 install pyscreenshot

Version
========
* Odoo 13 version

Track Deleted Records
=======================

    The users who has admin access rights that users can see which records have been deleted and by whom.
