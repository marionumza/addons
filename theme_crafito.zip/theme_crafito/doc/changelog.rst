================================================
``theme_crafito`` changelog
================================================

******************************************
Fixed some css issues
******************************************

Fixed some css issues


******************************************
Fixed an issue of category display in multi website
******************************************

1. Fixed an issue of category display in multi website


******************************************
Fixed an issue of category search
******************************************

1. Fixed an issue of category search


******************************************
Fixed some issues
******************************************

1. Fixed an issue of single variants
2. Fixed an issue related to pricelist in related and suggested products
3. Fixed some responsive and overlapping issues


******************************************
New Features Enhancement
******************************************

1. Added color picker for changing theme colors.
2. Added feature for changing breadcrumb background image.


******************************************
Fixed an issue of empty cart
******************************************

1. Fixed an issue which is showing traceback in console while removing the item from the cart

******************************************
Fixed an issue of price slider filter
******************************************

1. Fixed an issue of price slider filter

******************************************
Fixed an issue for product variant image change in Multi image
******************************************

1. Fixed an issue for product variant image change in Multi image

******************************************
Fixed an issue of stock related message
******************************************

1. Fixed an issue of stock related message