====================
Bug Management
====================

Installation
============
`Install <https://blog.miftahussalam.com/install-apps-odoo/>`__ this module in a usual way

Configuration
=============
`Activate Developer Mode <https://www.youtube.com/watch?v=sRc4xYPza7g>`__

Usage
=====
* Go to ``Project >> All Bugs >> Create``

Uninstallation
==============
Uninstall this module in a usual way <https://www.youtube.com/watch?v=DUfnQ2UU2rI>`__
