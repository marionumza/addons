# Bug-Management-System
Support for Odoo Open source platform 
