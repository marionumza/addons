# Odoo13-Prevent-create-new-product-from-order-lines
Sometimes a user can accidentally create a new product from the sales order lines or from purchase order lines.
      Thus will make an effect on the report, which items are sold or purchased..?,
using this module we can prevent users make the mistakes.

You can also download this module on [apps.odoo.com](https://apps.odoo.com/apps/modules/13.0/prevent_create_new_product_from_order_lines/)
