from . import res_partner, product_product, res_config_settings
