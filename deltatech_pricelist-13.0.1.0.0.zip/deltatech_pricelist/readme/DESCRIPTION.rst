
Features:
 - pretul de lista din datele de baza ale produsului poate sa fie in alta moneda
 - list price from basic data of the product can be in another currency
