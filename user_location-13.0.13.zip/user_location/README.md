Uer Location App
------------------------------------

Odoo Version : Odoo 13.0 Community 


Installation 
-------------------------------------
Install the Application => Apps -> User Location(user_location)


Overview
-------------------------------------
This module will allow to users to see them logged in info(logged in date/ location).
