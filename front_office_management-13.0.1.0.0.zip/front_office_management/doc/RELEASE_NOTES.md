## Module <front_office_management>

#### 28.10.2019
#### Version 13.0.1.0.0
##### ADD
- Migrated to version 13
