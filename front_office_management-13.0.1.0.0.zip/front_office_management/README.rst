===========================
Front Office Management v11
===========================

Helps You To Manage Front Office Operations.

Installation
============

Just install the module.

Configuration
=============

Nothing to configure.

Credits
=======
Anusha P P @ cybrosys, anusha@cybrosys.in
Niyas Raphy @ cybrosys, niyas@cybrosys.in


