Website Search Blog
===================
Blog Search Feature in Odoo 13 Website.


Features
========
* Search field in Blog
* Auto Suggestion List
* Search Results from all categories

Credits
=======
Cybrosys Techno Solutions <www.cybrosys.com>

Author
------
*  Developer V13: Hajaj Roshan @ cybrosys

