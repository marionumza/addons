Quotation Cancel Reason
-----------------------

This module will help to assign valid cancellation reason on the sales quotation, while cancelling the particular sales quotation.
