
=> 27/12/19 ==> 13.0.0.1 ==> view file issue fixed.

