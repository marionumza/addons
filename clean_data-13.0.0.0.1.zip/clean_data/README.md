Mass Clean Data
-------------------------------------------------

Odoo Version : Odoo 13.0 Community


Installation 
-------------------------------------------------------------
Install the Application => Apps -> Mass Clear Data(clean_data)


Overview
-------------------------------------------------------------
* Settings > Clean Data > Clean Data.
* This module will allows users clear multiple objects records from the wizard.

13.0.0.0.1
-------------------------------------------------------------
-Improve code and resolve dependency's issue.